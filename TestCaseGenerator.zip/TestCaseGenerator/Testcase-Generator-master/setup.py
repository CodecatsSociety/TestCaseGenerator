from setuptools import setup, find_packages

setup(name="tc_generator", packages=find_packages())
