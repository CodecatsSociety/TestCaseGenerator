module.exports = {
  mongoURI:
    'mongodb://heroku_ms8kbhq9:nsr88ibrleg9rg2js5fld85ncm@ds249035.mlab.com:49035/heroku_ms8kbhq9'
}
