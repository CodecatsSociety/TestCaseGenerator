#include <bits/stdc++.h>
using namespace std;
#define debug(x) cout<<#x<<":"<<x<<endl;


class Solution {
public:
    bool isValid(string s) {
        stack<char> st;
        for(auto& val:s){
            if(val == '(' || val == '[' || val == '{'){
                st.push(val);
            }else if(val == ')'){
                if(st.empty()){
                    return false;
                }
                if(st.top() == '('){
                    st.pop();
                }else{
                    return false;
                }              
            }else if(val == ']'){
                if(st.empty()){
                    return false;
                }
                if(st.top() == '['){
                    st.pop();
                }else{
                    return false;
                }
            }else if(val == '}'){
                if(st.empty()){
                    return false;
                }
                if(st.top() == '{'){
                    st.pop();
                }else{
                    return false;
                }
            }
        }
        if(!st.empty()){
            return false;
        }
        return true;
    }
};

int main(){
    Solution obj;
    string s;
    cin>>s;
    bool ans = obj.isValid(s);
    if(ans){
        cout<<"Yes";
    }else{
        cout<<"No";
    }
}