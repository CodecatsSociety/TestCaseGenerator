import random
def strgen():
	string = "abcdefghijklmnopqrstuvwxyz"
	string = string + "!"
	st = [char for char in string]
	res = ''.join(random.choices(st, k=random.randint(10,1000)))
	return res

k = strgen();
for ch in k:
	print(ch)