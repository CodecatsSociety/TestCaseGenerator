#include <stdio.h>
#include <conio.h>

vector<string> ans;


bool sorter(pair<string,string>& p1,pair<string,string>& p2){
	return p1.first <= p2.first;
}

void sendmail(vector<string>& emails){
	vector<pair<string,string>> vec; // firstadd,emails
	for(auto& email:emails){
		auto found = str.find('@');
		string cpy = str.substr(0,found);
		vec.push_back({cpy,emails});
	}
	sort(vec.begin(),vec.end(),sorter);
	for(auto& pr : vec){
		ans.push_back(pr.first);
	}
}

void solve(){
	int n;
	cin>>n;
	vector<string> emails;
	for(int i = 0; i < n; i++){
		cin>>emails[i];
	}
	solve(emails);
	for(auto& email : ans){
		cout<<email<<endl;
	}
}

int main() {
	solve();
	return 0;
}
